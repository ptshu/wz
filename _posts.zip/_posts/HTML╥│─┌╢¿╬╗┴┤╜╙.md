---
title: HTML页内定位链接
date: 2024-06-11 19:55:48
categories:
  - 网络智能
tags:
top:
---
HTML页内定位链接可以通过使用锚点（anchor）实现
<!--more-->

```
<!DOCTYPE html>
<html>
<head>
    <title>页内定位示例</title>
</head>
<body>
 
<h2><a href="#section1">第一部分</a></h2>
<h2><a href="#section2">第二部分</a></h2>
 
<div id="section1">这是第一部分的内容。</div>
<div id="section2">这是第二部分的内容。</div>
 
</body>
</html>
```