---
title: 使用HTML音频标签
date: 2023-11-19 21:29:10
categories:
  - hexo博客
tags:
top:
---
HTML提供了音频标签，可以用来嵌入音频文件到网页中。可以使用以下代码将音频文件嵌入到网页中：

`<audio src="bj.mp3" autoplay loop></audio>`

其中，src属性指定音频文件的路径，autoplay属性用于自动播放音频，loop属性用于循环播放音频。
<!--more-->