---
title: HTML页面完美适应手机浏览
date: 2024-06-26 22:48:37
categories:
  - 网络智能
tags:
top:
---
把以下代码（一行）插入HTML文件的<head></head>之间
```
<meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0,
maximum-scale=2.0,user-scalable=yes" name="viewport">
```
<!--more-->



说明：为了代码显示方便，把长代码分成了两行，实际使用时改成一行。