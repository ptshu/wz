---
title: github网页设置成中文
date: 2024-06-02 21:27:10
categories:
  - hexo博客
tags:
top:
---
方法：
使用谷歌浏览器Chrome
第一步：下载并安装油猴（不会搜百度教程）
第二步：开启油猴，在获取新脚本搜github汉化插件下载即可
<!--more-->