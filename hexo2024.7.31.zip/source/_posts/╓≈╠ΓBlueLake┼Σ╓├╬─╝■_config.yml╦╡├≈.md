---
title: 主题BlueLake配置文件_config.yml说明
date: 2024-07-03 22:48:37
categories:
  - hexo博客
tags:
top:
---
打开themes/BlueLake/_config.yml进行配置

version - 用于自动刷新CDN上的静态文件。
dark - 深色/浅色 切换。
favicon - 浏览器标签页图标
<!--more-->

banner/banner-dark：背景图
menu - 导航菜单。
Plugins - 需要安装的（网站地图）插件
sitemap - 网站地图文件路径
excerpt_link - 阅读更多按钮文本
fancybox - 图片查看器
copyright - 文章版权信息
date_formats - 日期格式
sidebar - 侧边栏位置
widgets - 侧边栏中的窗口小部件。
archive_type - 侧边栏归档显示方式(yearly/monthly)
archive_format - 侧边栏归档显示日期格式
show_count - 侧边栏是否显示计数
recent_posts_limits - 侧边栏最新文章显示条数
Toc - 文章目录
share - 分享
reward - 打赏功能.
about - 关于我页面配置
gitalk - Gitalk评论配置
valine - Valine评论配置
changyan - 畅言评论配置
comment- 其他评论配置
links - 友情链接